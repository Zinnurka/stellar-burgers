import { TOrder, TUser } from '@utils-types';

export const localStorageMock = (function () {
  let store: { [key: string]: string } = {};

  return {
    getItem(key: string) {
      return store[key] || null;
    },
    setItem(key: string, value: string) {
      store[key] = value;
    },
    removeItem(key: string) {
      delete store[key];
    },
    clear() {
      store = {};
    }
  };
})();

export const userDataMock: TUser = {
  email: 'ramil@zinnyrov.ru',
  name: 'Ramil Zinnyrov'
};

export const orderDataMock: TOrder[] = [
  {
    _id: '1',
    status: 'done',
    name: 'Order 1',
    createdAt: '2023-01-01',
    updatedAt: '2023-01-02',
    number: 12345,
    ingredients: ['1', '2', '3']
  }
];
